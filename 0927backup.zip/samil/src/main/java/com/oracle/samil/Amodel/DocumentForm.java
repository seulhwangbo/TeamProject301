package com.oracle.samil.Amodel;

import lombok.Data;

@Data
public class DocumentForm {
	public int 		documentFormId;		//문서서식ID
	public String 	documentFormTitle;	//문서서식제목
}
