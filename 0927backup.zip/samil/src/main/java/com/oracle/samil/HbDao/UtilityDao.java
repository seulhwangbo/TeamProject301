package com.oracle.samil.HbDao;

import java.util.List;

import com.oracle.samil.Amodel.Utility;

public interface UtilityDao {

	List<Utility> getUtilityList();

}
