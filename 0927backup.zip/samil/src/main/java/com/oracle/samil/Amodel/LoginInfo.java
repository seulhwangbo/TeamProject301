package com.oracle.samil.Amodel;

import lombok.Data;

@Data
public class LoginInfo {
	
	private int empno;
	private int passQuiz;
	private String password;
	private String passAnswer;

}
