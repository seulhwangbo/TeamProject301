package com.oracle.samil.ADto;

import lombok.Data;

@Data
public class AttCost {
	private int 		empno;			//사원번호

		private int			costYear; 		//비용문서번호
		private int 		codeNum; 	    //비용항목코드
		private String	costTitle;			//제목
		private int		    costMoney;   	//금액
		private String   attach;				//첨부파일
		private int        coststatus;				//처리상태
		private String   signdate; 		//신청날짜

		private String 	name;			//이름
		private int 	deptno;			//부서번호
		private int 	grade;			//직급
		private int 	job;			//직책
		private int 	status;			//근로상태
		private int 	admin;			//관리자권한
		private boolean delCheck;		//삭제여부

}
